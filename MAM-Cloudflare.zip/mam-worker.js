const MODEL = '@cf/meta/llama-3.2-1b-instruct';

function allowedOrigin(request, env) {
  const origin = request.headers.get('Origin') || '';
  const configured = (env.ALLOWED_ORIGIN || '').trim().replace(/\/$/, '');
  // Set ALLOWED_ORIGIN to the exact GitHub Pages origin, e.g. https://name.github.io
  return configured && origin === configured ? origin : null;
}

function json(data, status, origin) {
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Vary': 'Origin',
  };
  if (origin) {
    headers['Access-Control-Allow-Origin'] = origin;
    headers['Access-Control-Allow-Methods'] = 'POST, OPTIONS';
    headers['Access-Control-Allow-Headers'] = 'Content-Type';
  }
  return new Response(JSON.stringify(data), { status, headers });
}

export default {
  async fetch(request, env) {
    const origin = allowedOrigin(request, env);
    if (request.method === 'OPTIONS') {
      if (!origin) return new Response(null, { status: 403 });
      return new Response(null, { status: 204, headers: {
        'Access-Control-Allow-Origin': origin,
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Max-Age': '86400',
        'Vary': 'Origin',
      }});
    }
    if (request.method !== 'POST') return json({ error: 'Usa POST.' }, 405, origin);
    if (!origin) return json({ error: 'Origen web no autorizado. Configura ALLOWED_ORIGIN con la URL de GitHub Pages de MAM.' }, 403, null);

    let body;
    try { body = await request.json(); }
    catch { return json({ error: 'El cuerpo debe ser JSON válido.' }, 400, origin); }

    if (!Array.isArray(body.messages) || body.messages.length < 1 || body.messages.length > 12) {
      return json({ error: 'Envía entre 1 y 12 mensajes.' }, 400, origin);
    }
    const messages = body.messages.map((m) => {
      if (!m || !['user', 'assistant', 'system'].includes(m.role) || typeof m.content !== 'string') return null;
      return { role: m.role, content: m.content.slice(0, 4000) };
    });
    if (messages.some((m) => !m)) return json({ error: 'Formato de mensajes no válido.' }, 400, origin);

    try {
      const result = await env.AI.run(MODEL, {
        messages,
        max_tokens: 400,
        temperature: 0.7,
      });
      const reply = result?.response || result?.result?.response || result?.choices?.[0]?.message?.content;
      if (!reply) return json({ error: 'El modelo no devolvió texto. Prueba otra vez.' }, 502, origin);
      return json({ reply: String(reply) }, 200, origin);
    } catch (err) {
      return json({ error: 'Falló el servicio de IA. Comprueba la cuota gratuita y vuelve a probar.', detail: String(err?.message || err).slice(0, 250) }, 502, origin);
    }
  },
};
